﻿# TOJI Installer Scaffold (TOJI OS 2.0 + Sovereign X)

This scaffold contains:
- Installer Service (Flask) with OpenAPI
- Helm chart to deploy the Installer Service
- Kubernetes CRD for AppInstall
- Operator skeleton (Go) for AppInstall lifecycle
- Windows PowerShell helper scripts for build, airgap, and packaging

Quick start (local):
1. Build and run the installer service:
   cd installer-service
   docker build -t registry.local/toji/installer:dev .
   docker run -p 8080:8080 registry.local/toji/installer:dev

2. Install Helm chart (adjust values):
   helm install toji-installer ./helm/installer-chart

3. Operator (development):
   go run ./operator

Packaging repo:
From repo root:
.\package_repo.ps1

This creates toji-installer-scaffold.zip
