# signature_verifier.py
# Placeholder signature verification for scaffold
# Replace with cosign + KMS/HSM integration for production

def verify_signature(artifact_ref: str, signature: str) -> bool:
    # For scaffold, accept any non-empty signature longer than 10 chars
    if signature and len(signature) > 10:
        return True
    return False