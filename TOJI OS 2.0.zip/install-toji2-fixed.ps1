<#
install-toji2-fixed.ps1
- Unpack scaffold zip if present
- Create minimal installer-service scaffold if missing
- Build and run installer Docker container
- Apply CRD (kubectl) and install Helm chart if available
- Run basic smoke tests against local installer
Run as Administrator.
#>

param(
  [string]$RepoZip = "C:\toji2\toji-installer-scaffold.zip",
  [string]$RepoDir = "C:\toji2",
  [string]$ImageName = "toji/installer:dev",
  [int]$HealthWaitSeconds = 5
)

function Log($m){ Write-Host "[toji] $m" }

# ensure elevated
if (-not ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
  Write-Error "Please run this script as Administrator."
  exit 1
}

# ensure repo dir exists or expand zip
if (Test-Path $RepoZip) {
  Log "Found zip at $RepoZip. Expanding to $RepoDir ..."
  try {
    if (-not (Test-Path $RepoDir)) { New-Item -Path $RepoDir -ItemType Directory -Force | Out-Null }
    Expand-Archive -Path $RepoZip -DestinationPath $RepoDir -Force
    Log "Expanded zip."
  } catch {
    Write-Error "Failed to expand zip: $_"
    exit 1
  }
} elseif (-not (Test-Path $RepoDir)) {
  Write-Error "Neither zip ($RepoZip) nor folder ($RepoDir) exist. Place scaffold zip at $RepoZip or create $RepoDir and re-run."
  exit 1
} else {
  Log "Using existing directory $RepoDir."
}

# helper to write literal files
function Write-LiteralFile($path, $content) {
  $dir = Split-Path $path -Parent
  if (-not (Test-Path $dir)) { New-Item -Path $dir -ItemType Directory -Force | Out-Null }
  Set-Content -LiteralPath $path -Value $content -Encoding UTF8
  Log "Wrote $path"
}

# If installer-service missing, create minimal scaffold
$installerPath = Join-Path $RepoDir "installer-service"
$appDir = Join-Path $installerPath "app"
if (-not (Test-Path $installerPath)) {
  Log "installer-service not found. Creating minimal scaffold at $installerPath ..."
  New-Item -Path $appDir -ItemType Directory -Force | Out-Null

  $installer_py = @'
# installer_service.py (minimal scaffold)
from flask import Flask, request, jsonify
import os, tempfile, uuid, json, datetime
app = Flask(__name__)

@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status":"ok"}), 200

@app.route("/v1/apps/publish", methods=["POST"])
def publish():
    # minimal accept-only endpoint for scaffold
    return jsonify({"artifactId": "artifact-"+uuid.uuid4().hex}), 201

@app.route("/v1/apps/<name>/simulate", methods=["POST"])
def simulate(name):
    return jsonify({"allowed": True, "violations": []}), 200

@app.route("/v1/apps/<name>/install", methods=["POST"])
def install(name):
    install_id = "install-"+uuid.uuid4().hex
    return jsonify({"installId": install_id, "status": "success"}), 201

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 8080)))
'@
  Write-LiteralFile (Join-Path $appDir "installer_service.py") $installer_py

  $requirements = @'
Flask==2.2.5
'@
  Write-LiteralFile (Join-Path $installerPath "requirements.txt") $requirements

  $dockerfile = @'
FROM python:3.11-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY app/ /app
ENV PORT=8080
EXPOSE 8080
CMD ["python", "installer_service.py"]
'@
  Write-LiteralFile (Join-Path $installerPath "Dockerfile") $dockerfile

  # optional sample manifest
  $manifest = @'
apiVersion: toji.io/v1
kind: AppPackage
metadata:
  name: acme-inspector
  version: "1.0.0"
spec:
  packageType: "oci"
'@
  Write-LiteralFile (Join-Path $appDir "app-manifest.yaml") $manifest

  Log "Minimal installer-service scaffold created."
} else {
  Log "installer-service exists at $installerPath"
}

# Check Docker availability
try {
  docker version > $null 2>&1
} catch {
  Write-Error "Docker CLI not available or Docker not running. Start Docker Desktop and re-run."
  exit 1
}
Log "Docker available."

# Build Docker image
try {
  Push-Location $installerPath
  Log "Building Docker image $ImageName ..."
  $build = docker build -t $ImageName .
  Pop-Location
  Log "Docker image built."
} catch {
  Write-Error "Docker build failed: $_"
  exit 1
}

# Run container (remove existing)
try {
  $existing = docker ps -a --format "{{.Names}}" | Select-String -Pattern "^toji-installer$"
  if ($existing) {
    Log "Removing existing container 'toji-installer' ..."
    docker rm -f toji-installer | Out-Null
  }
} catch { }

Log "Starting installer container (port 8080) ..."
try {
  docker run -d --name toji-installer -p 8080:8080 $ImageName | Out-Null
} catch {
  Write-Error "Failed to start container: $_"
  exit 1
}

Start-Sleep -Seconds $HealthWaitSeconds

# Health check
$healthUrl = "http://localhost:8080/health"
try {
  $resp = Invoke-RestMethod -Uri $healthUrl -Method GET -ErrorAction Stop
  if ($resp.status -eq "ok") { Log "Installer service healthy at $healthUrl" } else { Write-Warning "Health returned unexpected payload." }
} catch {
  Write-Warning "Health check failed: $_"
  Start-Sleep -Seconds 3
  try { $resp = Invoke-RestMethod -Uri $healthUrl -Method GET -ErrorAction Stop; Log "Installer health: $($resp | ConvertTo-Json -Depth 2)" } catch { Write-Error "Installer not responding. Check container logs: docker logs toji-installer"; exit 1 }
}

# Apply CRD if present and kubectl available
$crdPath = Join-Path $RepoDir "k8s\crds\appinstall-crd.yaml"
if (Test-Path $crdPath) {
  try {
    Log "Applying CRD via kubectl ..."
    & kubectl apply -f $crdPath
    Log "CRD applied."
  } catch {
    Write-Warning "kubectl apply failed or kubectl not configured: $_"
  }
} else {
  Log "No CRD file found at $crdPath; skipping CRD apply."
}

# Helm install if chart exists and helm available
$chartPath = Join-Path $RepoDir "helm\installer-chart"
if (Test-Path $chartPath) {
  try {
    Log "Installing Helm chart (namespace 'toji') ..."
    & kubectl create namespace toji --dry-run=client -o yaml | kubectl apply -f -
    & helm upgrade --install toji-installer $chartPath --namespace toji --set image.repository="toji/installer",image.tag="dev"
    Log "Helm chart installed/upgraded."
  } catch {
    Write-Warning "Helm install failed or helm not present: $_"
  }
} else {
  Log "No Helm chart found at $chartPath; skipping Helm install."
}

# Smoke tests against local installer
try {
  $simulateUrl = "http://localhost:8080/v1/apps/acme-inspector/simulate"
  $simulateBody = @{ sovereignId = "sovereign-123"; profile = "edge-small" } | ConvertTo-Json
  Log "Calling simulate endpoint..."
  $simResp = Invoke-RestMethod -Uri $simulateUrl -Method POST -Body $simulateBody -ContentType "application/json" -ErrorAction Stop
  Log "Simulate response: $($simResp | ConvertTo-Json -Depth 3)"
} catch {
  Write-Warning "Simulate call failed: $_"
}

try {
  $installUrl = "http://localhost:8080/v1/apps/acme-inspector/install"
  $installBody = @{ sovereignId = "sovereign-123"; profile = "edge-small"; signature = "placeholder-signature-xxxxxxxx" } | ConvertTo-Json
  Log "Calling install endpoint..."
  $instResp = Invoke-RestMethod -Uri $installUrl -Method POST -Body $installBody -ContentType "application/json" -ErrorAction Stop
  Log "Install response: $($instResp | ConvertTo-Json -Depth 3)"
} catch {
  Write-Warning "Install call failed: $_"
}

Log "Finished. Check container logs: docker logs toji-installer"
Log "If you want the full scaffold files instead of the minimal scaffold, place the full repo at $RepoDir and re-run."
