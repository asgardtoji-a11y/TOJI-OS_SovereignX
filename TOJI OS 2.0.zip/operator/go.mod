module github.com/toji/installer-operator

go 1.20

require (
    sigs.k8s.io/controller-runtime v0.14.0
    k8s.io/apimachinery v0.27.0
)