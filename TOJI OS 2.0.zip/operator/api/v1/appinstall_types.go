package v1

import (
    metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
)

type AppInstallSpec struct {
    AppName     string `json:"appName,omitempty"`
    Version     string `json:"version,omitempty"`
    Profile     string `json:"profile,omitempty"`
    SovereignId string `json:"sovereignId,omitempty"`
    ManifestRef string `json:"manifestRef,omitempty"`
}

type AppInstall struct {
    metav1.TypeMeta   `json:",inline"`
    metav1.ObjectMeta `json:"metadata,omitempty"`
    Spec              AppInstallSpec `json:"spec,omitempty"`
}