# test-smoke.ps1
# Run basic smoke tests against local installer at http://localhost:8080
try {
  $health = Invoke-RestMethod -Uri http://localhost:8080/health -Method GET -ErrorAction Stop
  Write-Host "Health:" $health.status
} catch {
  Write-Error "Health check failed: $_"
}

try {
  $sim = Invoke-RestMethod -Uri http://localhost:8080/v1/apps/acme-inspector/simulate -Method POST -Body (@{sovereignId="sovereign-123";profile="edge-small"} | ConvertTo-Json) -ContentType "application/json"
  Write-Host "Simulate:" ($sim | ConvertTo-Json -Depth 3)
} catch {
  Write-Warning "Simulate failed: $_"
}

try {
  $inst = Invoke-RestMethod -Uri http://localhost:8080/v1/apps/acme-inspector/install -Method POST -Body (@{sovereignId="sovereign-123";profile="edge-small";signature="placeholder-signature-xxxxxxxx"} | ConvertTo-Json) -ContentType "application/json"
  Write-Host "Install:" ($inst | ConvertTo-Json -Depth 3)
} catch {
  Write-Warning "Install failed: $_"
}