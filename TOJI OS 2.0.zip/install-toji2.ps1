# install-toji2.ps1 (run as Admin)
$RepoZip = "C:\toji2\toji-installer-scaffold.zip"
$RepoDir = "C:\toji2"
if (-not (Test-Path $RepoZip)) { Write-Error "Place toji-installer-scaffold.zip at $RepoZip and re-run"; exit 1 }
Expand-Archive -Path $RepoZip -DestinationPath $RepoDir -Force
# Build installer image
cd "$RepoDir\installer-service"
docker build -t toji/installer:dev .
# Run locally (dev)
docker run -d --name toji-installer -p 8080:8080 toji/installer:dev
Start-Sleep -Seconds 3
# Verify health
$health = Invoke-RestMethod -Uri http://localhost:8080/health -Method GET -ErrorAction SilentlyContinue
if ($health.status -ne "ok") { Write-Warning "Installer health check failed"; } else { Write-Host "Installer running" }
# Apply CRD (requires kubectl configured)
kubectl apply -f "$RepoDir\k8s\crds\appinstall-crd.yaml" || Write-Warning "kubectl apply failed (check kubeconfig)"
# Helm install (namespace toji)
kubectl create namespace toji -o yaml --dry-run=client | kubectl apply -f -
helm upgrade --install toji-installer "$RepoDir\helm\installer-chart" --namespace toji --set image.repository=toji/installer,image.tag=dev
# Smoke test publish/simulate/install (local installer)
Invoke-RestMethod -Uri "http://localhost:8080/v1/apps/acme-inspector/simulate" -Method POST -Body (@{sovereignId="sovereign-123";profile="edge-small"} | ConvertTo-Json) -ContentType "application/json"
Write-Host "Done. Check http://localhost:8080 for API endpoints and Kubernetes for Helm deployment."
