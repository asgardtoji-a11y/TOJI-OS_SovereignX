﻿# installer_service.py (scaffold)
from flask import Flask, request, jsonify
from werkzeug.utils import secure_filename
import os, tempfile, json, datetime, uuid
from signature_verifier import verify_signature
from policy_simulator import run_policy_simulation
from evidence_collector import EvidenceCollector

app = Flask(__name__)
EVID = EvidenceCollector(storage_dir=os.environ.get("EVIDENCE_DIR", "/tmp/evidence"))

@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status":"ok"}), 200

@app.route("/v1/apps/publish", methods=["POST"])
def publish():
    manifest = request.files.get("manifest")
    bundle = request.files.get("bundle")
    if not manifest or not bundle:
        return jsonify({"error":"manifest and bundle required"}), 400
    tmpdir = tempfile.mkdtemp()
    manifest_path = os.path.join(tmpdir, secure_filename(manifest.filename))
    bundle_path = os.path.join(tmpdir, secure_filename(bundle.filename))
    manifest.save(manifest_path)
    bundle.save(bundle_path)
    artifact_id = f"artifact-{uuid.uuid4().hex}"
    EVID.record_event(sovereign_id=None, pilot_id=None, event_type="publish", payload={"artifactId": artifact_id, "manifest": manifest.filename})
    return jsonify({"artifactId": artifact_id}), 201

@app.route("/v1/apps/<name>/simulate", methods=["POST"])
def simulate(name):
    body = request.json or {}
    sovereign = body.get("sovereignId")
    profile = body.get("profile")
    manifest = {"name": name}
    sim_result = run_policy_simulation(manifest, sovereign, profile)
    EVID.record_event(sovereign, None, "policy.simulation", {"app": name, "result": sim_result})
    return jsonify(sim_result), 200

@app.route("/v1/apps/<name>/install", methods=["POST"])
def install(name):
    body = request.json or {}
    sovereign = body.get("sovereignId")
    profile = body.get("profile")
    signature = body.get("signature")
    sig_ok = verify_signature(artifact_ref=name, signature=signature)
    if not sig_ok:
        EVID.record_event(sovereign, None, "install.blocked", {"app": name, "reason": "signature_invalid"})
        return jsonify({"allowed": False, "reason": "signature_invalid"}), 403
    sim = run_policy_simulation({"name": name}, sovereign, profile)
    if not sim.get("allowed", False):
        EVID.record_event(sovereign, None, "install.blocked", {"app": name, "policy": sim})
        return jsonify({"allowed": False, "policy": sim}), 403
    install_id = f"install-{uuid.uuid4().hex}"
    EVID.record_event(sovereign, None, "install.request", {"app": name, "installId": install_id})
    EVID.record_event(sovereign, None, "install.complete", {"app": name, "installId": install_id, "status": "success"})
    return jsonify({"installId": install_id, "status": "success"}), 201

@app.route("/v1/evidence/<bundle_id>/export", methods=["GET"])
def export_evidence(bundle_id):
    bundle = EVID.export_bundle(bundle_id)
    if not bundle:
        return jsonify({"error":"not found"}), 404
    return jsonify(bundle), 200

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 8080)))
