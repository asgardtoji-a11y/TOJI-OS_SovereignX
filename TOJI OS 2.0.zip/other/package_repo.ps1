﻿# package_repo.ps1
param(
  [string]$RepoRoot = "C:\toji2",
  [string]$OutZip = ""
)
if ([string]::IsNullOrWhiteSpace($OutZip)) {
  $OutZip = Join-Path $RepoRoot "toji-installer-scaffold.zip"
}
if (-not (Test-Path $RepoRoot)) { throw "Repo root not found: $RepoRoot" }
if (Test-Path $OutZip) { Remove-Item $OutZip -Force }
Add-Type -AssemblyName System.IO.Compression.FileSystem
[System.IO.Compression.ZipFile]::CreateFromDirectory($RepoRoot, $OutZip)
Write-Host "Created package: $OutZip"
