﻿param(
  [string]$Image = "registry.local/toji/installer:dev",
  [string]$Context = ".\installer-service"
)
try {
  $ErrorActionPreference = "Stop"
  Write-Host "Building Docker image $Image from context $Context ..."
  docker build -t $Image $Context
  Write-Host "Pushing Docker image $Image ..."
  docker push $Image
  Write-Host "Build and push completed: $Image"
} catch {
  Write-Error "Build or push failed: $_"
  exit 1
}
