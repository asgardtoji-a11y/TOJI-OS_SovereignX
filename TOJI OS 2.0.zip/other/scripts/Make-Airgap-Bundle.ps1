﻿param(
  [Parameter(Mandatory=$true)][string]$AppName,
  [Parameter(Mandatory=$true)][string]$Version,
  [string]$OutDir = ".\airgap",
  [string]$Registry = "registry.local/toji"
)
try {
  $ErrorActionPreference = "Stop"
  $fullImage = "$Registry/$AppName:$Version"
  Write-Host "Creating airgap bundle for $fullImage"
  if (-not (Test-Path $OutDir)) { New-Item -Path $OutDir -ItemType Directory -Force | Out-Null }
  Write-Host "Pulling image $fullImage ..."
  docker pull $fullImage
  $imageTar = Join-Path $OutDir "$($AppName -replace '/','-')-$Version-image.tar"
  Write-Host "Saving image to $imageTar ..."
  docker save $fullImage -o $imageTar
  $manifestSrc = ".\installer-service\app\app-manifest.yaml"
  if (Test-Path $manifestSrc) { Copy-Item -Path $manifestSrc -Destination $OutDir -Force }
  $bundleName = Join-Path $OutDir "$($AppName -replace '/','-')-$Version-airgap.zip"
  if (Test-Path $bundleName) { Remove-Item $bundleName -Force }
  Add-Type -AssemblyName System.IO.Compression.FileSystem
  [System.IO.Compression.ZipFile]::CreateFromDirectory($OutDir, $bundleName)
  Write-Host "Airgap bundle created: $bundleName"
} catch {
  Write-Error "Airgap bundle creation failed: $_"
  exit 1
}
