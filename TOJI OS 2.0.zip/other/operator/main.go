﻿package main

import (
    "log"
    "os"
)

func main() {
    log.Println("Installer operator skeleton starting")
    if os.Getenv("DEV") == "1" {
        log.Println("Dev mode: operator skeleton ready")
    }
}
