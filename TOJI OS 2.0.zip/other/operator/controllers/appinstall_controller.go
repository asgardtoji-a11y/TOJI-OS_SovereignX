﻿package controllers

import (
    "context"
    "log"
    "sigs.k8s.io/controller-runtime/pkg/client"
)

type AppInstallReconciler struct {
    Client client.Client
}

func (r *AppInstallReconciler) Reconcile(ctx context.Context, req client.ObjectKey) error {
    log.Printf("Reconciling AppInstall: %v", req)
    return nil
}
